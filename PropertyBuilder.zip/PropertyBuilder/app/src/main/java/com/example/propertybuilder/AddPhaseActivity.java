package com.example.propertybuilder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.propertybuilder.ConstantApis.Api;
import com.example.propertybuilder.ConstantApis.MySingleton;
import com.example.propertybuilder.databinding.ActivityAddPhaseBinding;
import com.google.gson.Gson;

import net.alhazmy13.mediapicker.Image.ImagePicker;
import net.alhazmy13.mediapicker.Video.VideoPicker;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import hb.xvideoplayer.MxVideoPlayer;

public class AddPhaseActivity extends AppCompatActivity {

    ActivityAddPhaseBinding binding;
    public static final String TAG = "wow123";
    ArrayList<String> arrayList_images = new ArrayList<>();
    ArrayList<Uri> mArrayUri;
    int position = 0;
    Intent intent;
    String postId;
    int PICK_IMAGE_MULTIPLE = 1;

    public void adjustFontScale(Configuration configuration) {
        configuration.fontScale = (float) 1.0;
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getMetrics(metrics);
        metrics.scaledDensity = configuration.fontScale * metrics.density;
        getBaseContext().getResources().updateConfiguration(configuration, metrics);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        adjustFontScale(getResources().getConfiguration());
        binding = ActivityAddPhaseBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        intent = getIntent();
        mArrayUri = new ArrayList<Uri>();
        toolBarSetup();
        setUpImageSeletor();
        clicks();

         postId = intent.getStringExtra("addId");
    }

    private void clicks() {
        binding.confirmPhaseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phaseDes = binding.phaseDesc.getText().toString();

                if (arrayList_images.isEmpty()){
                    Toast.makeText(AddPhaseActivity.this, "Select Images For Phase", Toast.LENGTH_SHORT).show();
                }else if (phaseDes.isEmpty()){
                    binding.phaseDesc.requestFocus();
                    binding.phaseDesc.setError("Enter Phase Description");
                }else {
                    binding.progressBar.setVisibility(View.VISIBLE);
                    binding.confirmPhaseBtn.setVisibility(View.GONE);
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.ADD_PHASE_NEW, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Log.d(TAG, "onResponse:000000    " + response + "     00000");

                            finish();

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(AddPhaseActivity.this, "Error"+error.getMessage(), Toast.LENGTH_SHORT).show();
                            binding.progressBar.setVisibility(View.GONE);
                            binding.confirmPhaseBtn.setVisibility(View.VISIBLE);
                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {

                            Gson gson = new Gson();
                            String data = gson.toJson(arrayList_images);

                            Map<String, String> params = new HashMap<>();
                            params.put("description", phaseDes);
                            params.put("images", data);
                            params.put("post_id", postId);

                            return params;
                        }
                    };
                    MySingleton.getInstance(AddPhaseActivity.this).addToRequestQueue(stringRequest);
                }
            }
        });
    }

    private void setUpImageSeletor() {
        binding.image.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView = new ImageView(getApplicationContext());
                return imageView;
            }
        });
        binding.next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position < mArrayUri.size() - 1) {
                    // increase the position by 1
                    position++;
                    binding.image.setImageURI(mArrayUri.get(position));
                } else {
//                    Toast.makeText(AddPostActivity.this, "Last Image Already Shown", Toast.LENGTH_SHORT).show();
                }
            }
        });
        binding.previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position > 0) {
                    // decrease the position by 1
                    position--;
                    binding.image.setImageURI(mArrayUri.get(position));
                }
            }
        });
        binding.selectFeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();

                // setting type to select to be image
                intent.setType("image/*");

                // allowing multiple image to be selected
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_MULTIPLE);
            }
        });
        binding.selectVideoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                selectVideoFromGallery();

            }
        });
    }

    private void selectVideoFromGallery() {
        new VideoPicker.Builder(AddPhaseActivity.this)
                .mode(VideoPicker.Mode.CAMERA_AND_GALLERY)
                .directory(VideoPicker.Directory.DEFAULT)
                .extension(VideoPicker.Extension.MP4)
                .enableDebuggingMode(true)
                .build();
    }


    @SuppressLint("UseCompatLoadingForDrawables")
    private void toolBarSetup() {
        binding.toolBar.setTitle("Add Phase");
        binding.toolBar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_baseline_arrow_back_24));
        binding.toolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_MULTIPLE && resultCode == RESULT_OK && null != data) {
            if (data.getClipData() != null) {
                ClipData mClipData = data.getClipData();
                int cout = data.getClipData().getItemCount();
                for (int i = 0; i < cout; i++) {
                    Uri imageurl = data.getClipData().getItemAt(i).getUri();
                    if (!imageurl.equals(null) || cout == 0) {
                        binding.selectFeb.setVisibility(View.GONE);
                        binding.next.setVisibility(View.VISIBLE);
                        binding.previous.setVisibility(View.VISIBLE);
                    }


                    Bitmap bitmap = null;
                    try {
                        bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageurl);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 10, byteArrayOutputStream);
                    final String encodedImage = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT);

                    Log.d("wow123", "StringArrayImages: " + encodedImage);

                    arrayList_images.add(encodedImage);


                    mArrayUri.add(imageurl);

                }
                position = 0;
            } else {
                Bitmap bitmap = null;

                Uri imageurl = data.getData();
                mArrayUri.add(imageurl);

                try {
                    bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageurl);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 10, byteArrayOutputStream);
                final String encodedImage = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT);

                arrayList_images.add(encodedImage);


//                binding.image.setImageURI(mArrayUri.get(0));
                position = 0;
            }
        }

    }

}