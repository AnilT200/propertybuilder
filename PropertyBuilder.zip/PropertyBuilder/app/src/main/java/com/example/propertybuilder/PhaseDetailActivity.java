package com.example.propertybuilder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.propertybuilder.Adapters.ViewPagerAdapter;
import com.example.propertybuilder.ConstantApis.Api;
import com.example.propertybuilder.ConstantApis.MySingleton;
import com.example.propertybuilder.databinding.ActivityPhaseDetailBinding;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class PhaseDetailActivity extends AppCompatActivity {

    ActivityPhaseDetailBinding binding;
    private int dotscount;
    private ImageView[] dots;
    public static final String TAG = "wow123";
    ArrayList<String> images = new ArrayList<>();
    ViewPagerAdapter mViewPagerAdapter;
    Intent intent;
    String phaseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPhaseDetailBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        intent = getIntent();
        toolBarSetup();
        phaseId = intent.getStringExtra("phaseID");
        imagesApiCall();
    }
    private void imagesApiCall() {
        images.clear();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.GET_IMAGES_NEW, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("wow123", "onResponse images: " + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    for (int i = 0; i < (jsonObject.length() - 2); i++) {
                        JSONObject jsonObject1 = jsonObject.getJSONObject(i + "");
                        Log.d("wow123", "onResponse: " + jsonObject1.getString("image"));

                        images.add(jsonObject1.getString("image"));
                    }
                    setupPager();

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Log.d(TAG, "onErrorResponse: " + error.getMessage());
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("phase_id", phaseId);
                return params;
            }
        };
        MySingleton.getInstance(PhaseDetailActivity.this).addToRequestQueue(stringRequest);

    }

    private void setupPager() {


        mViewPagerAdapter = new ViewPagerAdapter(PhaseDetailActivity.this, images);

        binding.viewPager.setAdapter(mViewPagerAdapter);
        dotscount = mViewPagerAdapter.getCount();

        dots = new ImageView[dotscount];

        for (int i = 0; i < dotscount; i++) {

            dots[i] = new ImageView(this);
            dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_selected_dots));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            params.setMargins(8, 0, 8, 0);

            binding.SliderDots.addView(dots[i], params);

            binding.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                    for (int i = 0; i < dotscount; i++) {
                        dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_selected_dots));
                    }

                    dots[position].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.selected_dots));
                }

                @Override
                public void onPageSelected(int position) {

                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });

        }
    }
    @SuppressLint("UseCompatLoadingForDrawables")
    private void toolBarSetup() {
        binding.toolBar.setTitle("Phase Detail");
        binding.toolBar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_baseline_arrow_back_24));
        binding.toolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}