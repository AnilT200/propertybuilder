package com.example.propertybuilder.ConstantApis;

public class Api {
    public static final String ROOT_IP_ADDRESS = "192.168.42.80";
    public static final String CUS_REGISTER= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/cus_register.php";
    public static final String CUS_LOGIN= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/cus_login.php";
    public static final String CUS_PROFILE_UPDATE= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/cus_update.php";
    public static final String DEV_ADD_POST= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/add_post.php";
    public static final String IMAGE_BASE_URL= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/uploads/";
    public static final String GET_DEVELOPER_DATA= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/get_all_posts_developer.php";
    public static final String GET_USER_DATA= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/get_all_posts.php";
    public static final String GET_ALL_IMAGES= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/get_images.php";
    public static final String SEND_COMMENTS= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/add_comment.php";
    public static final String GET_COMMENTS= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/get_all_comments.php";
    public static final String EDIT_POST= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/post_update.php";
    public static final String DELETE_POST= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/delete_post.php";
    public static final String DELETE_IMAGE= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/delete_post_images.php";
    public static final String ADD_IMAGE= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/add_images.php";
    public static final String USER_PASSWORD= "USER_PASSWORD";

    /////////////////////////////////////////////////////////////////////////////////////////////
    public static final String ADD_POST_NEW= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/add_post_with_lat.php";
    public static final String ADD_PHASE_NEW= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/add_phase.php";
    public static final String GET_PHASE_NEW= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/get_phases.php";
    public static final String GET_IMAGES_NEW= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/get_images.php";
    public static final String ADD_APPOINTMENT_NEW= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/add_appointment.php";
    public static final String EDIT_APPOINTMENT_NEW= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/update_appointment.php";
    public static final String GET_APPOINTMENT_DEVELOPER_NEW= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/get_appointment_by_developer_id.php";
    public static final String GET_APPOINTMENT_ADMIN_NEW= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/get_appointment_by_admin.php";
    public static final String GET_ALL_STAFF= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/get_all_developers.php";
    public static final String DELETE_STAFF= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/delete_developer_user.php";
    public static final String CHANGE_PASSWORD= "http://"+ROOT_IP_ADDRESS+"/propertyBuilder/update_user_developer_password.php";

}
