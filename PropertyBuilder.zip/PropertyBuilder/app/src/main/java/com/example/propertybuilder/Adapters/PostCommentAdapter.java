package com.example.propertybuilder.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.propertybuilder.Models.PostCommentModel;
import com.example.propertybuilder.Models.UserDataModel;
import com.example.propertybuilder.R;

import java.util.List;

public class PostCommentAdapter extends RecyclerView.Adapter<PostCommentAdapter.CommentViewHolder> {
    private Context context;
    private List<PostCommentModel> postCommentModelList;

    public PostCommentAdapter(Context context, List<PostCommentModel> postCommentModelList) {
        this.context = context;
        this.postCommentModelList = postCommentModelList;
    }

    @NonNull
    @Override
    public PostCommentAdapter.CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.comment_items, parent, false);
        return new PostCommentAdapter.CommentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostCommentAdapter.CommentViewHolder holder, int position) {
        holder.userName.setText(postCommentModelList.get(position).getUserName());
        holder.userComment.setText(postCommentModelList.get(position).getUserComment());
    }

    @Override
    public int getItemCount() {
        return postCommentModelList.size();
    }

    public class CommentViewHolder extends RecyclerView.ViewHolder {
        TextView userName;
        TextView userComment;
        public CommentViewHolder(@NonNull View itemView) {
            super(itemView);

            userName = itemView.findViewById(R.id.userName);
            userComment = itemView.findViewById(R.id.userComment);
        }
    }
}
