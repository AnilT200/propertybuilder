package com.example.propertybuilder.Adapters;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.propertybuilder.ConstantApis.Api;
import com.example.propertybuilder.ConstantApis.MySingleton;
import com.example.propertybuilder.InspectionRequestActivity;
import com.example.propertybuilder.Models.BookingDateModel;
import com.example.propertybuilder.Models.UserModel;
import com.example.propertybuilder.R;
import com.example.propertybuilder.SharedPreference.SharedPrefManager;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.jetbrains.annotations.NotNull;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class BookingDateAdapter extends RecyclerView.Adapter<BookingDateAdapter.BookingDateViewHolder> {
    private Context context;
    private List<BookingDateModel> bookingDateModelList;

    public BookingDateAdapter(Context context, List<BookingDateModel> bookingDateModelList) {
        this.context = context;
        this.bookingDateModelList = bookingDateModelList;
    }

    @NonNull
    @NotNull
    @Override
    public BookingDateViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.booking_date_items, parent, false);
        return new BookingDateAdapter.BookingDateViewHolder(view);
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    public void onBindViewHolder(@NonNull @NotNull BookingDateAdapter.BookingDateViewHolder holder, int position) {
        holder.customerNameBooking.append(bookingDateModelList.get(position).getCustomerName()+" "+"book for an"+
                " "+bookingDateModelList.get(position).getBookingType());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context);
                bottomSheetDialog.setContentView(R.layout.bottom_sheet_booking_details);
                ImageView closeBD = bottomSheetDialog.findViewById(R.id.close_booking_details);
                TextView details = bottomSheetDialog.findViewById(R.id.booking_details_date);
                Button btnReply = bottomSheetDialog.findViewById(R.id.btnReply);
                assert details != null;
                details.append(bookingDateModelList.get(position).getCustomerName()+" "+
                        "book for an"+" "+bookingDateModelList.get(position).getBookingType()+" "+
                        bookingDateModelList.get(position).getBookingDate()+" "+
                        "at time slot"+" "+bookingDateModelList.get(position).getBookingTime());

                assert closeBD != null;
                closeBD.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        bottomSheetDialog.cancel();
                    }
                });
                btnReply.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final Dialog dialog = new Dialog(context);
                        dialog.setContentView(R.layout.booking_edit_dialog);
                        // if button is clicked, close the custom dialog
                        EditText bookingDateEdt = dialog.findViewById(R.id.bookingDate_dv_edit);
                        ImageView bookingCalender = dialog.findViewById(R.id.bookingCalender_dv_edit);
                        EditText timeSlotDropEdt = dialog.findViewById(R.id.timeSlot_spin_edit);
                        Button confirm = dialog.findViewById(R.id.booking_confirm_btn_edit);
                        Button cancel = dialog.findViewById(R.id.booking_cancel_btn_edit);


                        bookingCalender.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                DatePickerDialog picker;
                                final Calendar cldr = Calendar.getInstance();
                                int day = cldr.get(Calendar.DAY_OF_MONTH);
                                int month = cldr.get(Calendar.MONTH);
                                int year = cldr.get(Calendar.YEAR);
                                picker = new DatePickerDialog(context,
                                        new DatePickerDialog.OnDateSetListener() {
                                            @SuppressLint("SetTextI18n")
                                            @Override
                                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                                bookingDateEdt.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                                                bookingDateEdt.setError(null);
                                            }
                                        }, year, month, day);
                                picker.show();
                            }
                        });
                        dialog.show();

                        timeSlotDropEdt.setOnTouchListener(new View.OnTouchListener() {
                            @Override
                            public boolean onTouch(View v, MotionEvent event) {
                                if (event.getAction() == MotionEvent.ACTION_UP){
                                    PopupMenu popup = new PopupMenu(context, timeSlotDropEdt);
                                    //Inflating the Popup using xml file
                                    popup.getMenuInflater()
                                            .inflate(R.menu.time_slots, popup.getMenu());
                                    popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                        public boolean onMenuItemClick(MenuItem item) {
                                            String timeSlot = String.valueOf(item.getTitle());
                                            timeSlotDropEdt.setText(timeSlot);
                                            timeSlotDropEdt.setError(null);

                                            return true;
                                        }
                                    });
                                    popup.show();

                                    return true;
                                }
                                return false;
                            }
                        });


                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });
                        confirm.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                UserModel usersModel = SharedPrefManager.getInstance(context).getUser();
                                String userId = String.valueOf(usersModel.getId());
                                String bookingDate = bookingDateEdt.getText().toString();
                                String bookingTimeSlot = timeSlotDropEdt.getText().toString();

                                if(bookingDate.isEmpty()) {
                                    bookingDateEdt.requestFocus();
                                    bookingDateEdt.setError("Confirm Your Booking Date");
                                }
                                else if (bookingTimeSlot.isEmpty()){
                                    timeSlotDropEdt.requestFocus();
                                    timeSlotDropEdt.setError("Confirm Your Time Slot");
                                } else {
                                    StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.EDIT_APPOINTMENT_NEW, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            Log.d("wow123", "onResponse: "+response);
                                            dialog.dismiss();

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            Log.d("wow123", "onErrorResponse: "+error.getMessage());
                                        }
                                    }){
                                        @Override
                                        protected Map<String, String> getParams() throws AuthFailureError {
                                            Map<String,String> params = new HashMap<>();
                                            params.put("appointment_id",bookingDateModelList.get(position).getAppointmentId());
                                            params.put("date",bookingDate);
                                            params.put("time",bookingTimeSlot);
                                            params.put("developer_id",userId);
                                            params.put("user_id",bookingDateModelList.get(position).getCustomerID());
                                            params.put("post_id",bookingDateModelList.get(position).getPostID());

                                            return params;
                                        }
                                    };
                                    MySingleton.getInstance(context).addToRequestQueue(stringRequest);

                                }
                            }
                        });
                        dialog.setCancelable(false);
                    }
                });
                bottomSheetDialog.setCancelable(false);
                bottomSheetDialog.show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return bookingDateModelList.size();
    }

    public class BookingDateViewHolder extends RecyclerView.ViewHolder {
        TextView customerNameBooking;
        public BookingDateViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            customerNameBooking = itemView.findViewById(R.id.customerBookingDate);
        }
    }
}
