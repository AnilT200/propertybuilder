package com.example.propertybuilder;

import com.example.propertybuilder.Models.PhaseModel;

public interface InterFaceClass {
    void onItemClick(PhaseModel item);
}
